# BucclApp Dev Harness

Claude Code 기반 3-track 개발 자동화 파이프라인. Django/DRF 프로젝트에 특화.

## 트랙 비교

| 트랙 | 언제 쓰나 | 코드 수정 | 최종 출력 |
|------|----------|----------|---------|
| `/buccl:planning` | 무엇을 만들지 확정 전 | 없음 (문서만) | ADR 드래프트 → adr.yaml 편입 |
| `/buccl:maintenance` | 버그, 리팩토링, 성능 개선 | 있음 (범위 제한적) | 수정 커밋 + 회귀 리포트 |
| `/buccl:feature` | 새 기능/서비스 추가 | 있음 (범위 큼) | PR + 리뷰 반영 완료 코드 |

## 실행 모드 분포

| 트랙 | Fork | Sub-agent | Agent Team |
|------|------|-----------|------------|
| 기획 | P1, P2, P5, P6 | P3 | P4 (대안 분석) |
| 유지보수 | M2, M6, M7 | M3, M5, M9 | M4 (영향도), M8 (회귀) |
| 신규개발 | F2, F4, F6, F8 | F3, F5, F7 | — |

## 트랙 간 전이

```
기획 → /update-docs adr (승인 게이트) → 신규개발 → 유지보수
                                          ↑                |
                                          └── 에스컬레이션 ←┘
```

## 산출물 구조

```
.harness-artifacts/
  planning/{plan-YYYYMMDD-slug}/
    scope.md, stakeholders.md, requirements-interview.md,
    external-research.md, alternatives.md, feasibility.md,
    decision-draft.md, INDEX.md
  maintenance/{issue-id}/
    reproduction.md, root-cause.md, impact-analysis.md,
    convention-check.md, fix-plan.md, regression-report.md,
    review-comments.md, INDEX.md
  feature/{branch-name}/
    requirements.md, prior-art.md, design-intent.md,
    code-quality-guide.md, pr-body.md, review-comments.md,
    INDEX.md
```

## 참조 문서

```
docs/
  code-convention.yaml    — 코딩 컨벤션 (27개 규칙)
  adr.yaml                — Architecture Decision Records
  architecture.yaml       — 시스템 구조 맵
  module-registry.yaml    — Django 앱 모듈 레지스트리
```

## Quick Start

1. `docs/` 하위 4개 파일을 프로젝트에 맞게 수정한다.
2. Claude Code에서 작업 유형에 맞는 트랙을 실행한다.

## License

MIT
